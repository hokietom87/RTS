﻿using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RTS.Common
{
    public class HttpGlobalExceptionFilter : ExceptionFilterAttribute
    {
        //private ILogger<HttpGlobalExceptionFilter> _logger;

        // I didn't actually add logging but it's easy to do... went ahead and put in the global exception handler 
        public void OnException(ILogger<HttpGlobalExceptionFilter> logger, ExceptionContext context)
        {
            //_logger = logger;
            //_logger.LogError("Exceptions caught by global exception filter:", context.Exception);

        }
    }
}
