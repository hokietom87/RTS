﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using RTS.Interview.Data;
using RTS.Models;

namespace RTS.Controllers
{
    public class HomeController : Controller
    {

        private readonly IOptions<AppSettings> appSettings;

        public HomeController( IOptions<AppSettings> app)
        {
            appSettings = app;

        }

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult ArrayShtuff()
        {
            return View();
        }

        public ActionResult StringThing()
        {
            return View();
        }

        [HttpPost]
        public JsonResult GetEmailList()
        {
            try
            {
                // kind of bogus to pass file name in directory
                string dir = appSettings.Value.DataDirectory;
                EmailTemplateXmlFileRepository emailData = new EmailTemplateXmlFileRepository(dir);

                var data = emailData.Where(x => x.Active);
                return Json(new { ErrorFlag = false, Message = "Success", Data = data.Result });

            }
            catch (Exception ex)
            {
                return Json(new { ErrorFlag = true, Message = ex.Message });
            }

        }
        [HttpPost]
        public JsonResult GetVersions(string label, Guid id)
        {
            try
            {
                // kind of bogus to pass file name in directory
                string dir = appSettings.Value.DataDirectory;
                EmailTemplateXmlFileRepository emailData = new EmailTemplateXmlFileRepository(dir);

                // some folks don't like using var as the code isn't as readable wrt to data types
                // i go back and forth on that
                var email = emailData.Single(id);
                var versions = email.Result.Versions;

                return Json(new { ErrorFlag = false, Message = "Success", Data = versions });

            }
            catch (Exception ex)
            {
                return Json(new { ErrorFlag = true, Message = ex.Message });
            }




        }


        [HttpPost]
        public JsonResult ShiftIt(string orig, int shiftlength)
        {

            string result = "";
            string err = "";
            try
            {
                int origlength = orig.Length;

                if (!string.IsNullOrEmpty(orig) && orig.Length > 1)
                {
                    if (shiftlength > 0 && origlength >= shiftlength)
                    {
                        result = string.Format("{0}{1}", orig.Substring(origlength-shiftlength), orig.Substring(0, origlength-shiftlength));
                    }
                    else
                    {
                        err = "Shift Length is invalid";

                    }
                }
                else
                {
                    err = "String is invalid";


                }


            }
            catch (Exception ex)
            {
                err = ex.Message;


            }

            return Json(new { ErrorMessage = err, Data = result });

        }
        [HttpGet]
        public JsonResult CountIt(string orig, int comparenum)
        {
            
            string result = "";
            string err = "";
            try
            {
                // convert string into array
                string[] origarray = orig.Split(',');
                if (!Array.TrueForAll(origarray, IsNumber))
                {
                    err = "All elements need to be integers";
                }
                else
                {
                    List<string> tempList = origarray.ToList();
                    // already verified that we have integers to doing parse is okay
                    List<int> compareList = tempList.Select(x => int.Parse(x)).ToList();
                    // many ways to do it... I did a list to show a little linq
                    result = string.Format("{0} number(s) below and {1} number(s) above", compareList.Where(x => x < comparenum).Count(), compareList.Where(x => x > comparenum).Count());

                }


            }
            catch (Exception ex)
            {
                err = ex.Message;
            }

            return Json(new { ErrorMessage = err, Data = result });

        }
        private static bool IsNumber(String value)
        {
            int s;
            return int.TryParse(value, out s);
        }
    }

}
