﻿$(document).ready(function () {
    Common.RegisterCustomEvents();
    Email.LoadData();

});

// I started using the jquery module pattern in the past year.   It just cleans up the organization when the js files get big.

var Common = {

    AsyncAjaxWithoutStatus: function (getOrPost, url, data, successCallback, errorCallback, passThrough) {
        // This is a common ajax call that I normally use in mvc applications.   There are a couple of different versions of this that I use
        // but only included the one I use for this app

        $.ajax({
            async: true, type: getOrPost, url: url, data: data,
            success: function (jsonContent) {
                if (successCallback != null) {
                    successCallback(jsonContent, passThrough);
                }
            },
            error: function (xhr, error, errorThrown) {
                if (errorCallback) {
                    errorCallback(xhr.responseText, { returnSomethingOnError: false });
                }
                else {
                    Common.CommonError(xhr.responseText, { returnSomethingOnError: false })
                }
            }
        });
    },
    CommonError: function (errorMessage, returnValue) {
        // I normally use a better looking notification but this at least shows us something if we get ajax error
        alert(errorMessage);
    },
    DateFormatter(val) {
        var value = val.substring(0, 10);
        //  probably should find a better date formatter or even format the data on the server side
        var dt = new Date(value);
        year = dt.getFullYear();
        month = (dt.getMonth() + 1).toString().padStart(2, "0");
        day = dt.getDate().toString().padStart(2, "0");

        return month + '/' + day + '/' + year
    },
    RegisterCustomEvents: function () {
        $("#emailtable").on("collapse-row.bs.table", function (editable, columns, row) {
            $('#detailTable').bootstrapTable('destroy');

        });
    }
}

var Email = {
    LoadData: function () {
        Common.AsyncAjaxWithoutStatus('POST',
            "/Home/GetEmailList",
            {},
            Email.LoadDataCallBack);
    },
    LoadDataCallBack: function (result) {
        $('#emailtable').bootstrapTable({
            data: result.Data
        });
    },
    LoadVersionsCallBack: function (result, passThrough) {

        $('#detailTable').bootstrapTable('destroy');

        // You can build the bootstrap table on the fly or have it "predefined" in the cshtml like what is done in index.cshtml
        $('#detailTable').bootstrapTable({
            data: result.Data,
            columns: [
                {
                    field: 'Id',
                    title: 'Id'
                },
                {
                    field: 'EmailLabel',
                    title: 'EmailLabel'
                },
                {
                    field: 'Subject',
                    title: 'Subject'
                }
            ]

        });

    },
    DetailFormatter: function (index, row) {
        Common.AsyncAjaxWithoutStatus('POST',
            "/Home/GetVersions",
            { label: row.EmailLabel, id: row.Id },
            Email.LoadVersionsCallBack, null, { row: row });

        // stole this from bootstrap.. quick and dirty way to show details
        var html = []
        $.each(row, function (key, value) {
            html.push('<p><b>' + key + ':</b> ' + value + '</p>')
        })
        return html.join('')

    }
}

var ArrayShtuff = {

    CountIt: function () {
        // added a js check just to show it can be done here or on controller
        if ($("#CompareNumber").val() == null || $("#CompareNumber").val() == "") {
            alert("Compare Number required")
            return;
        }
        if ($("#InputString").val() == null || $("#InputString").val() == "") {
            alert("Input string required")
            return;
        }

        // obviously this doesn't have to be done on controller via ajax but what the heck
        Common.AsyncAjaxWithoutStatus('GET',
            "/Home/CountIt",
            { orig: $("#InputString").val(), comparenum: $("#CompareNumber").val() },
            ArrayShtuff.CountItCallBack);
    },
    CountItCallBack: function (result) {
        if (result.ErrorMessage != "") {
            alert(result.ErrorMessage);
        }
        else {
            $("#Result").html(result.Data);

        }
    }

}

var StringThing = {

    ShiftIt: function () {
        // added a js check just to show it can be done here or on controller
        if ($("#Shift").val() == null || $("#Shift").val() == "") {
            alert("Shift number required")
            return;
        }
        if ($("#InputString").val() == null || $("#InputString").val() == "") {
            alert("Input string required")
            return;
        }

        // obviously this doesn't have to be done on controller via ajax but what the heck
        Common.AsyncAjaxWithoutStatus('POST',
            "/Home/ShiftIt",
            { orig: $("#InputString").val(), shiftlength: $("#Shift").val() },
            StringThing.ShiftItCallBack);
    },
    ShiftItCallBack: function (result) {
        if (result.ErrorMessage != "") {
            alert(result.ErrorMessage);
        }
        else {
            $("#Result").html(result.Data);

        }
    }

}
